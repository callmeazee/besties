import Button from "../shared/Button";

const Video = () => {
  return (
    <div className="space-y-4">
      {/* PRINCIPAL PRIMARY FEED CAM WORKSPACE VIEWPORT */}
      <div className="bg-slate-950 w-full aspect-video relative rounded-2xl shadow-inner overflow-hidden border border-slate-800">
        <video
          className="w-full h-full object-cover absolute top-0 left-0"
          autoPlay
          playsInline
          muted></video>

        <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-lg text-white bg-slate-900/70 text-xs font-semibold">
          Rahul Kumar (You)
        </div>

        <button className="absolute bottom-3 right-3 w-8 h-8 rounded-lg text-white hover:bg-white/10 bg-slate-900/60 flex items-center justify-center transition-all active:scale-95 cursor-pointer">
          <i className="ri-fullscreen-line text-sm"></i>
        </button>
      </div>

      {/* SUBSCRIBER STREAM MULTI-PARTICIPANT ROW TRACK */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <div className="bg-slate-900 aspect-video rounded-xl relative overflow-hidden border border-slate-800">
          <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md text-white bg-slate-950/50 text-[10px] font-medium">
            Sarah Jenkins
          </div>
        </div>
        <div className="bg-slate-900 aspect-video rounded-xl relative overflow-hidden border border-slate-800">
          <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md text-white bg-slate-950/50 text-[10px] font-medium">
            Alex Carter
          </div>
        </div>
      </div>

      {/* UTILITY MEDIA CALL COMMANDS CONSOLE BAR CONTAINER */}
      <div className="bg-white border border-gray-100 p-3 rounded-2xl flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2">
          <button className="bg-gray-100 text-gray-700 w-10 h-10 rounded-xl hover:bg-gray-200 transition-colors flex items-center justify-center cursor-pointer active:scale-95">
            <i className="ri-vidicon-line text-base"></i>
          </button>
          <button className="bg-gray-100 text-gray-700 w-10 h-10 rounded-xl hover:bg-gray-200 transition-colors flex items-center justify-center cursor-pointer active:scale-95">
            <i className="ri-mic-line text-base"></i>
          </button>
          <button className="bg-blue-50 text-blue-600 w-10 h-10 rounded-xl hover:bg-blue-100 transition-colors flex items-center justify-center cursor-pointer active:scale-95">
            <i className="ri-computer-line text-base"></i>
          </button>
        </div>

        <div className="w-full sm:w-auto">
          <Button
            type="danger"
            icon="close-circle-line"
            className="w-full sm:w-auto text-xs py-2 px-4 rounded-xl font-bold justify-center shadow-none h-10"
            onClick={() => alert("Disconnecting session...")}>
            End Connection
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Video;
